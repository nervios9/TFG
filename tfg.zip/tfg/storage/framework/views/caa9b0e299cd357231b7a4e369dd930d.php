<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <div class="container">
        <h1>Catalogo de Libros</h1>
    <form method="GET" action="<?php echo e(route('buscador')); ?>">
            <?php echo csrf_field(); ?>
        <select name="opcion">
            <?php $__currentLoopData = $listaGeneros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($genero->id); ?>"><?php echo e($genero->genero); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Buscar</button>
    </form>
        <table>
            <?php $__currentLoopData = $listaLibros ->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="imagenesLibros"><a href="<?php echo e(route('show',[$libros->id])); ?>"><img style="height: 300px"  src="<?php echo e(url('images/libros/' .$libros->imagen)); ?>"alt="Portada Libro"></a></td>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
<?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/all.blade.php ENDPATH**/ ?>