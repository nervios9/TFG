<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
<?php $__env->startSection('show', 'info peliculas'); ?>
<?php $__env->startSection( 'content'); ?>
<div class="container">
   
<h1><?php echo e($libros->nombre); ?></h1>


    <img style="height: 400px" id="imagenesPeliculas" src="<?php echo e(url('images/libros/' .$libros->imagen)); ?>"alt="portada libro">


   

       
<p>Autor <?php echo e($libros ->escritor->nombre); ?></p>
   
<p>Autor <?php echo e($libros ->genero->genero); ?></p>
  
<p>Fecha de estreno: <?php echo e($libros->fecha_salida); ?></p>
<p>Paginas: <?php echo e($libros->paginas); ?></p>

<p>Synopsis: <?php echo e($libros->synopsis); ?></p>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/show.blade.php ENDPATH**/ ?>