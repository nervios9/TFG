<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
<?php $__env->startSection('show', 'info peliculas'); ?>
<?php $__env->startSection( 'content'); ?>
<div class="container">
   
<h1><?php echo e($libro->nombre); ?></h1>


    <img style="height: 400px" id="imagenesPeliculas" src="<?php echo e(url('images/libros/' .$libro->imagen)); ?>"alt="portada libro">


   

       
<p>Autor: <?php echo e($libro->escritor->nombre); ?> <?php echo e($libro->escritor->apellidos); ?></p>
   
<p>Genero: <?php echo e($libro ->genero->genero); ?></p>

<p>Fecha de estreno: <?php echo e($libro->fecha_salida); ?></p>
<p>Paginas: <?php echo e($libro->paginas); ?></p>

<p>Synopsis: <?php echo e($libro->synopsis); ?></p>


    <form method="POST" action="<?php echo e(route('librosLeidos')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="usuario" value="<?php echo e(Auth::user()->id); ?>">
        <input type="hidden" name="libro_id" value="<?php echo e($libro->id); ?>">
        <input type="checkbox" name="leido">
        Libro Leído
        <button type="submit">Guardar</button>
       
    </form>


<form action="<?php echo e(route('enviarDatos')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="input-row">
        <input type="hidden" name="comment_id" id="post" placeholder="Nombre" />
        <label for="nombre" class="form-label">Usuario:</label> 
        <input class="form-control" type="text" name="nombre" id="nombre" readonly value= <?php echo e(Auth::user()->name); ?> required/>
    </div>
    <div class="input-row">
        <label for="comme" class="form-label">Comentario:</label>
            <p class="emoji-picker-container">
              <textarea rows="6" class="form-control" 
              type="text" name="comentario" id="comentario" placeholder="Agregue su comentario" required></textarea>
            </p>
        </div>
        <input type="hidden" name="usuario" value=<?php echo e(Auth::user()->id); ?>>
        <input type="hidden" name="libro_id" value=<?php echo e($libro->id); ?>>
    <button type="submit">Enviar</button>
</form>


<h2>Comentarios:</h2>
<ul>
    <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
           
         
            <?php echo e($comentario->comentario); ?> - 
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/show.blade.php ENDPATH**/ ?>