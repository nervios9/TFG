<?php
if (!isset($_SESSION['logged_in'])) {
    ?>
    <a class="login" href="<?php echo e(url('login.php')); ?>">Iniciar Sesion</a>
    <a  class="register" href="<?php echo e(url('register.php')); ?>">Registrarse</a>

   <?php
}else{
?>
<div>
    <img src="<?php echo e(asset('images/icono.png')); ?>" onclick="toggleMenu()" alt="icono" class="dropdown-imgIcono" tabindex="0">
   
    <div id="dropdown-menu" style="display: none;">
        <!-- Contenido del menú desplegable -->
        <p style="text-align:end;">Usuario:<?php print $_SESSION['nombre']?>

            <form style="text-align:end;" method="get" action="">
            <input  type="submit" name="eliminar_sesion" value="Cerrar Sesión">
            </form> 
        </p>
    
     
    </div>
</div>
<?php
}
?>
<script>
    var showMenu = false;

    function toggleMenu() {
        var menu = document.getElementById('dropdown-menu');
        showMenu = !showMenu;
        menu.style.display = showMenu ? 'block' : 'none';
    }

    function handleMenuItemClick() {
        var menu = document.getElementById('dropdown-menu');
        showMenu = false;
        menu.style.display = 'none';
    }
</script><?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/dropdownMenu.blade.php ENDPATH**/ ?>