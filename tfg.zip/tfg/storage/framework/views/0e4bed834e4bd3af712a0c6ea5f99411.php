<?php if(session('cookies_accepted')): ?>
    <div class="alert alert-info">
        Este sitio web utiliza cookies. Al continuar navegando, aceptas su uso.
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/partials/alerta_cookies.blade.php ENDPATH**/ ?>