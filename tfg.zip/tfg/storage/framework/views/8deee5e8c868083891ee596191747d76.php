<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <div class="container">
        <h1>Buscador:</h1>
        <a href="<?php echo e(url('/all')); ?>">Hacer otra consulta</a>
        <table>
            <?php $__currentLoopData = $listaLibros ->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="imagenesLibros"><a href="<?php echo e(route('show',[$libros->id])); ?>"><img style="height: 300px"  src="<?php echo e(url('images/libros/' .$libros->imagen)); ?>"alt="Portada Libro"></a></td>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br><br>
        <a href="<?php echo e(url('/all')); ?>">Hacer otra consulta</a>
        </div>
<?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/buscador.blade.php ENDPATH**/ ?>