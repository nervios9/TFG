<?php
set($_SESSION['logged_in']);
return Redirect::to('/');

  
?><?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/logout.blade.php ENDPATH**/ ?>