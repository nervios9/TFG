<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>



<?php $__currentLoopData = $listaLibrosLeidos ->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $fila; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $librosLeidos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td class="imagenesLibros"><a href="<?php echo e(route('show',[$librosLeidos->libro_id])); ?>"><img style="height: 300px"  src="<?php echo e(url('images/libros/' .$librosLeidos->imagen)); ?>"alt="Portada Libro"></a></td>
--}}
<p> <?php echo e($librosLeidos->id); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</body>
</html><?php /**PATH C:\xampp\htdocs\php\TFG\tfg\resources\views/mostrarLeidos.blade.php ENDPATH**/ ?>