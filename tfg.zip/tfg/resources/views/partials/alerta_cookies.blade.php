@if(session('cookies_accepted'))
    <div class="alert alert-info">
        Este sitio web utiliza cookies. Al continuar navegando, aceptas su uso.
    </div>
@endif